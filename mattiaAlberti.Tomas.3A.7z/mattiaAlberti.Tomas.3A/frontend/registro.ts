namespace Test
{
    export class Verificadora
    {
        public static ValidarCorreo(correo:string):boolean
        {
            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if(re.test(correo)==false)
            {
                (<HTMLInputElement>document.getElementById('correo')).outerHTML+="<span style='color:red;'>*</span>";
                (<HTMLDivElement>document.getElementById('alerta')).innerHTML='<div class="alert alert-danger" role="alert">Correo formato invalido</div>';
                return false;
            }
            return true;
        }

        public static ValidarClave(clave:string,confirmar:string):boolean
        {
            if(clave.length<4 || clave.length>8)
            {
                (<HTMLInputElement>document.getElementById('clave')).outerHTML+="<span style='color:red;'>*</span>";
                (<HTMLDivElement>document.getElementById('alerta')).innerHTML='<div class="alert alert-danger" role="alert">Clave formato invalido</div>';
                return false;
            }
            if(confirmar!=clave)
            {
                (<HTMLInputElement>document.getElementById('confirmar')).outerHTML+="<span style='color:red;'>*</span>";
                (<HTMLDivElement>document.getElementById('alerta')).innerHTML='<div class="alert alert-danger" role="alert">Las claves no coinciden</div>';
                return false;
            }
            return true;
        }

        public static ValidarNombre(nombre:string,apellido:string):boolean
        {
            if(apellido.length>15)
            {
                (<HTMLInputElement>document.getElementById('apellido')).outerHTML+="<span style='color:red;'>*</span>";
                (<HTMLDivElement>document.getElementById('alerta')).innerHTML='<div class="alert alert-danger" role="alert">apellido formato invalido</div>';
                return false;
            }
            if(nombre.length>10)
            {
                (<HTMLInputElement>document.getElementById('nombre')).outerHTML+="<span style='color:red;'>*</span>";
                (<HTMLDivElement>document.getElementById('alerta')).innerHTML='<div class="alert alert-danger" role="alert">apellido formato invalido</div>';
                return false;
            }
            return true;
        }

        public static ValidarLegajo(legajo:number):boolean
        {
            if(legajo<99 || legajo>999999)
            {
                (<HTMLInputElement>document.getElementById('legajo')).outerHTML+="<span style='color:red;'>*</span>";
                (<HTMLDivElement>document.getElementById('alerta')).innerHTML='<div class="alert alert-danger" role="alert">legajo formato invalido</div>';
                return false;
            }
            return true;
        }

        public static validarImagen():boolean 
        {
            let foto:any=(<HTMLInputElement>document.getElementById('foto'));
            var FileUploadPath = foto.value;
            
            if (FileUploadPath == '') 
            {
                (<HTMLInputElement>document.getElementById('foto')).outerHTML+="<span style='color:red;'>*</span>";
                (<HTMLDivElement>document.getElementById('alerta')).innerHTML='<div class="alert alert-danger" role="alert">Falta subir la imagen</div>';
                return false;
            }
            else 
            {
                var Extension = FileUploadPath.substring(FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
            
                if (Extension == "png" || Extension == "jpg") 
                {
                    return true;
                } 
                else 
                {
                    (<HTMLInputElement>document.getElementById('foto')).outerHTML+="<span style='color:red;'>*</span>";
                    (<HTMLDivElement>document.getElementById('alerta')).innerHTML='<div class="alert alert-danger" role="alert">La imagen tiene que ser JPG o PNG</div>';
                    return false;
                }
            }
        }

        public static VerificarVacios(nombre:string,apellido:string,correo:string,legajo:number,clave:string,confirmar:string):boolean
        {
            if(nombre=="" || clave=="" || apellido=="" ||correo=="" || legajo.toString()=="" ||confirmar=="")
            {
                return false;
            }
            return true;
        }

        public static Limpiar():void
        {
            (<HTMLInputElement>document.getElementById('correo')).value="";
            (<HTMLInputElement>document.getElementById('nombre')).value="";
            (<HTMLInputElement>document.getElementById('apellido')).value="";
            (<HTMLInputElement>document.getElementById('legajo')).value="";
            (<HTMLInputElement>document.getElementById('clave')).value="";
            (<HTMLInputElement>document.getElementById('confirmar')).value="";
        }

        public static LimpiarValidaciones():void
        {
            (<HTMLInputElement>document.getElementById('correo')).outerHTML="";
            (<HTMLInputElement>document.getElementById('nombre')).outerHTML="";
            (<HTMLInputElement>document.getElementById('apellido')).outerHTML="";
            (<HTMLInputElement>document.getElementById('legajo')).outerHTML="";
            (<HTMLInputElement>document.getElementById('clave')).outerHTML="";
            (<HTMLInputElement>document.getElementById('confirmar')).outerHTML="";
            (<HTMLInputElement>document.getElementById('correo')).style.color="";
            (<HTMLInputElement>document.getElementById('nombre')).style.color="black";
            (<HTMLInputElement>document.getElementById('apellido')).style.color="black";
            (<HTMLInputElement>document.getElementById('legajo')).style.color="black";
            (<HTMLInputElement>document.getElementById('clave')).style.color="black";
            (<HTMLInputElement>document.getElementById('confirmar')).style.color="black";
        }

        public static VerificarExistencia(correo:string):boolean
        {
            let bandera=0;
            if(localStorage.getItem('cuentas')==null)
            {
                return false;
            }

            let objeto:any=JSON.parse(localStorage.getItem('cuentas'));
            console.log(objeto.cuentas.length);
            for (let index = 0; index < objeto.cuentas.length; index++) {
                if(objeto.cuentas[index].correo==correo)
                {
                    console.log(objeto.cuentas[index]);
                    (<HTMLDivElement>document.getElementById('alerta')).innerHTML='<div class="alert alert-warning" role="alert">Existe la cuenta</div>';
                    bandera=1;
                    return false;
                }  
            }
            if(bandera==0)
            {
                return true;
            }
            return false;
        }

        public static VerificarRegistro():void
        {
            let nombre=(<HTMLInputElement>document.getElementById('nombre')).value;
            let apellido=(<HTMLInputElement>document.getElementById('apellido')).value;
            let correo=(<HTMLInputElement>document.getElementById('correo')).value;
            let legajo=parseInt((<HTMLInputElement>document.getElementById('legajo')).value);
            let clave=(<HTMLInputElement>document.getElementById('clave')).value;
            let perfil=(<HTMLSelectElement>document.getElementById('perfil')).value;
            let confirmar=(<HTMLInputElement>document.getElementById('confirmar')).value;

            if(Verificadora.VerificarVacios(nombre,apellido,correo,legajo,clave,confirmar)!=true)
            {
                (<HTMLDivElement>document.getElementById('alerta')).innerHTML='<div class="alert alert-danger" role="alert">Faltan Datos</div>';
                return;
            }
            if(Verificadora.ValidarNombre(nombre,apellido)!=true)
            {
                return;
            }
            if(Verificadora.ValidarCorreo(correo) !=true)
            {
                return;
            }
            if(Verificadora.ValidarLegajo(legajo) !=true)
            {
                return;
            }
            if(Verificadora.ValidarClave(clave,confirmar) !=true)
            {
                return;
            }
            if(Verificadora.validarImagen() !=true)
            {
                return;
            }

            if(Verificadora.VerificarExistencia(correo) !=true)
            {
                return;
            }
            console.log("paso todas las verificaciones");
            Verificadora.GuardarJson(nombre,apellido,correo,legajo,clave,perfil);
        }

        public static GuardarJson(nombre:string,apellido:string,correo:string,legajo:number,clave:string,perfil:string):void
        {
            let foto:any=(<HTMLInputElement>document.getElementById('foto'));
            var FileUploadPath = foto.value;
            var res = FileUploadPath.split("C:\\fakepath\\");
            let objetoNuevo:any =[{"correo":correo, "clave":clave, "nombre":nombre, "apellido":apellido, "legajo":legajo, "perfil":perfil, "foto":res}];
            console.log(JSON.stringify(objetoNuevo));
            console.log(res);
            let objeto:any=JSON.parse(localStorage.getItem('cuentas'));
            objeto.cuentas+=objetoNuevo;
            console.log(JSON.stringify(objeto.cuentas));
            localStorage.setItem('cuentas',JSON.stringify(objeto));
        }


    }
}