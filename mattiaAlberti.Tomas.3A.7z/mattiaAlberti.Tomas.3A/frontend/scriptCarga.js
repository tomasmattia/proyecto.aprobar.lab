window.onload = function () {
    if (localStorage.getItem('cuentas') == null) {
        var objeto = {
            "cuentas": [
                { "correo": "hola@hola.com", "clave": "1234", "nombre": "Doe", "apellido": "Doe", "legajo": "0421", "perfil": "Usuario", "foto": "hola.jpg" },
                { "correo": "chau@chau.com", "clave": "4567", "nombre": "Doe", "apellido": "Doe", "legajo": "0456", "perfil": "Admin", "foto": "chau.jpg" },
                { "correo": "Peter", "clave": "Jones", "nombre": "Doe", "apellido": "Doe", "legajo": "Doe", "perfil": "Doe", "foto": "Doe" },
                { "correo": "Peter", "clave": "Jones", "nombre": "Doe", "apellido": "Doe", "legajo": "Doe", "perfil": "Doe", "foto": "Doe" },
                { "correo": "Peter", "clave": "Jones", "nombre": "Doe", "apellido": "Doe", "legajo": "Doe", "perfil": "Doe", "foto": "Doe" }
            ]
        };
        console.log(JSON.stringify(objeto));
        localStorage.setItem('cuentas', JSON.stringify(objeto));
    }
    else {
        console.log("Ya estan cargadas las cuentas en el local");
        var objeto = JSON.parse(localStorage.getItem('cuentas'));
        console.log(objeto);
    }
};
