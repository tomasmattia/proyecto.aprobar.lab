var Test;
(function (Test) {
    var Manejadora = /** @class */ (function () {
        function Manejadora() {
        }
        Manejadora.Validar = function (correo, clave) {
            if (correo == "" || clave == "") {
                document.getElementById('alerta').innerHTML = '<div class="alert alert-danger" role="alert">Faltan Datos</div>';
                return false;
            }
            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if (re.test(correo) == false) {
                document.getElementById('correo').outerHTML += "<span style='color:red;'>*</span>";
                document.getElementById('alerta').innerHTML = '<div class="alert alert-danger" role="alert">Correo formato invalido</div>';
                return false;
            }
            if (clave.length < 4 || clave.length > 8) {
                document.getElementById('clave').outerHTML += "<span style='color:red;'>*</span>";
                document.getElementById('alerta').innerHTML = '<div class="alert alert-danger" role="alert">Clave formato invalido</div>';
                return false;
            }
            return true;
        };
        Manejadora.Logear = function () {
            var correo = document.getElementById('correo').value;
            var clave = document.getElementById('clave').value;
            var bandera = 0;
            if (Manejadora.Validar(correo, clave) != true) {
                return;
            }
            if (localStorage.getItem('cuentas') == null) {
                return;
            }
            var objeto = JSON.parse(localStorage.getItem('cuentas'));
            console.log(objeto.cuentas.length);
            for (var index = 0; index < objeto.cuentas.length; index++) {
                if (objeto.cuentas[index].correo == correo && objeto.cuentas[index].clave == clave) {
                    console.log(objeto.cuentas[index]);
                    console.log('Usuario valido');
                    bandera = 1;
                    window.location.assign('./registro.html');
                }
            }
            if (bandera == 0) {
                document.getElementById('alerta').innerHTML = '<div class="alert alert-warning" role="alert">No se encontro la cuenta</div>';
            }
        };
        return Manejadora;
    }());
    Test.Manejadora = Manejadora;
})(Test || (Test = {}));
