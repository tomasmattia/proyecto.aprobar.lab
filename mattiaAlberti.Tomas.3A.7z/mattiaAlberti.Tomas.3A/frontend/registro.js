var Test;
(function (Test) {
    var Verificadora = /** @class */ (function () {
        function Verificadora() {
        }
        Verificadora.ValidarCorreo = function (correo) {
            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if (re.test(correo) == false) {
                document.getElementById('correo').outerHTML += "<span style='color:red;'>*</span>";
                document.getElementById('alerta').innerHTML = '<div class="alert alert-danger" role="alert">Correo formato invalido</div>';
                return false;
            }
            return true;
        };
        Verificadora.ValidarClave = function (clave, confirmar) {
            if (clave.length < 4 || clave.length > 8) {
                document.getElementById('clave').outerHTML += "<span style='color:red;'>*</span>";
                document.getElementById('alerta').innerHTML = '<div class="alert alert-danger" role="alert">Clave formato invalido</div>';
                return false;
            }
            if (confirmar != clave) {
                document.getElementById('confirmar').outerHTML += "<span style='color:red;'>*</span>";
                document.getElementById('alerta').innerHTML = '<div class="alert alert-danger" role="alert">Las claves no coinciden</div>';
                return false;
            }
            return true;
        };
        Verificadora.ValidarNombre = function (nombre, apellido) {
            if (apellido.length > 15) {
                document.getElementById('apellido').outerHTML += "<span style='color:red;'>*</span>";
                document.getElementById('alerta').innerHTML = '<div class="alert alert-danger" role="alert">apellido formato invalido</div>';
                return false;
            }
            if (nombre.length > 10) {
                document.getElementById('nombre').outerHTML += "<span style='color:red;'>*</span>";
                document.getElementById('alerta').innerHTML = '<div class="alert alert-danger" role="alert">apellido formato invalido</div>';
                return false;
            }
            return true;
        };
        Verificadora.ValidarLegajo = function (legajo) {
            if (legajo < 99 || legajo > 999999) {
                document.getElementById('legajo').outerHTML += "<span style='color:red;'>*</span>";
                document.getElementById('alerta').innerHTML = '<div class="alert alert-danger" role="alert">legajo formato invalido</div>';
                return false;
            }
            return true;
        };
        Verificadora.validarImagen = function () {
            var foto = document.getElementById('foto');
            var FileUploadPath = foto.value;
            if (FileUploadPath == '') {
                document.getElementById('foto').outerHTML += "<span style='color:red;'>*</span>";
                document.getElementById('alerta').innerHTML = '<div class="alert alert-danger" role="alert">Falta subir la imagen</div>';
                return false;
            }
            else {
                var Extension = FileUploadPath.substring(FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
                if (Extension == "png" || Extension == "jpg") {
                    return true;
                }
                else {
                    document.getElementById('foto').outerHTML += "<span style='color:red;'>*</span>";
                    document.getElementById('alerta').innerHTML = '<div class="alert alert-danger" role="alert">La imagen tiene que ser JPG o PNG</div>';
                    return false;
                }
            }
        };
        Verificadora.VerificarVacios = function (nombre, apellido, correo, legajo, clave, confirmar) {
            if (nombre == "" || clave == "" || apellido == "" || correo == "" || legajo.toString() == "" || confirmar == "") {
                return false;
            }
            return true;
        };
        Verificadora.Limpiar = function () {
            document.getElementById('correo').value = "";
            document.getElementById('nombre').value = "";
            document.getElementById('apellido').value = "";
            document.getElementById('legajo').value = "";
            document.getElementById('clave').value = "";
            document.getElementById('confirmar').value = "";
        };
        Verificadora.LimpiarValidaciones = function () {
            document.getElementById('correo').outerHTML = "";
            document.getElementById('nombre').outerHTML = "";
            document.getElementById('apellido').outerHTML = "";
            document.getElementById('legajo').outerHTML = "";
            document.getElementById('clave').outerHTML = "";
            document.getElementById('confirmar').outerHTML = "";
            document.getElementById('correo').style.color = "";
            document.getElementById('nombre').style.color = "black";
            document.getElementById('apellido').style.color = "black";
            document.getElementById('legajo').style.color = "black";
            document.getElementById('clave').style.color = "black";
            document.getElementById('confirmar').style.color = "black";
        };
        Verificadora.VerificarExistencia = function (correo) {
            var bandera = 0;
            if (localStorage.getItem('cuentas') == null) {
                return false;
            }
            var objeto = JSON.parse(localStorage.getItem('cuentas'));
            console.log(objeto.cuentas.length);
            for (var index = 0; index < objeto.cuentas.length; index++) {
                if (objeto.cuentas[index].correo == correo) {
                    console.log(objeto.cuentas[index]);
                    document.getElementById('alerta').innerHTML = '<div class="alert alert-warning" role="alert">Existe la cuenta</div>';
                    bandera = 1;
                    return false;
                }
            }
            if (bandera == 0) {
                return true;
            }
            return false;
        };
        Verificadora.VerificarRegistro = function () {
            var nombre = document.getElementById('nombre').value;
            var apellido = document.getElementById('apellido').value;
            var correo = document.getElementById('correo').value;
            var legajo = parseInt(document.getElementById('legajo').value);
            var clave = document.getElementById('clave').value;
            var perfil = document.getElementById('perfil').value;
            var confirmar = document.getElementById('confirmar').value;
            if (Verificadora.VerificarVacios(nombre, apellido, correo, legajo, clave, confirmar) != true) {
                document.getElementById('alerta').innerHTML = '<div class="alert alert-danger" role="alert">Faltan Datos</div>';
                return;
            }
            if (Verificadora.ValidarNombre(nombre, apellido) != true) {
                return;
            }
            if (Verificadora.ValidarCorreo(correo) != true) {
                return;
            }
            if (Verificadora.ValidarLegajo(legajo) != true) {
                return;
            }
            if (Verificadora.ValidarClave(clave, confirmar) != true) {
                return;
            }
            if (Verificadora.validarImagen() != true) {
                return;
            }
            if (Verificadora.VerificarExistencia(correo) != true) {
                return;
            }
            console.log("paso todas las verificaciones");
            Verificadora.GuardarJson(nombre, apellido, correo, legajo, clave, perfil);
        };
        Verificadora.GuardarJson = function (nombre, apellido, correo, legajo, clave, perfil) {
            var foto = document.getElementById('foto');
            var FileUploadPath = foto.value;
            var res = FileUploadPath.split("C:\\fakepath\\");
            var objetoNuevo = [{ "correo": correo, "clave": clave, "nombre": nombre, "apellido": apellido, "legajo": legajo, "perfil": perfil, "foto": res }];
            console.log(JSON.stringify(objetoNuevo));
            console.log(res);
            var objeto = JSON.parse(localStorage.getItem('cuentas'));
            objeto.cuentas += objetoNuevo;
            console.log(JSON.stringify(objeto.cuentas));
            localStorage.setItem('cuentas', JSON.stringify(objeto));
        };
        return Verificadora;
    }());
    Test.Verificadora = Verificadora;
})(Test || (Test = {}));
