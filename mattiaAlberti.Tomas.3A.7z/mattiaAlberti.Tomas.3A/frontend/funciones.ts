namespace Test
{
    export class Manejadora
    {

        public static Limpiar():void
        {
            
        }

        public static Validar(correo:string,clave:string):boolean
        {
            if(correo=="" || clave=="")
            {
                (<HTMLDivElement>document.getElementById('alerta')).innerHTML='<div class="alert alert-danger" role="alert">Faltan Datos</div>';
                return false;
            }
            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if(re.test(correo)==false)
            {
                (<HTMLInputElement>document.getElementById('correo')).outerHTML+="<span style='color:red;'>*</span>";
                (<HTMLDivElement>document.getElementById('alerta')).innerHTML='<div class="alert alert-danger" role="alert">Correo formato invalido</div>';
                return false;
            }
            if(clave.length<4 || clave.length>8)
            {
                (<HTMLInputElement>document.getElementById('clave')).outerHTML+="<span style='color:red;'>*</span>";
                (<HTMLDivElement>document.getElementById('alerta')).innerHTML='<div class="alert alert-danger" role="alert">Clave formato invalido</div>';
                return false;
            }
            return true;
        }

        public static Logear():void
        {
            let correo=(<HTMLInputElement>document.getElementById('correo')).value;
            let clave=(<HTMLInputElement>document.getElementById('clave')).value;
            let bandera=0;
            if(Manejadora.Validar(correo,clave)!=true)
            {
                return;
            }
            if(localStorage.getItem('cuentas')==null)
            {
                return;
            }

            let objeto:any=JSON.parse(localStorage.getItem('cuentas'));
            console.log(objeto.cuentas.length);
            for (let index = 0; index < objeto.cuentas.length; index++) {
                if(objeto.cuentas[index].correo==correo && objeto.cuentas[index].clave==clave)
                {
                    console.log(objeto.cuentas[index]);
                    console.log('Usuario valido');
                    bandera=1;
                    window.location.assign('./registro.html');
                }  
            }
            if(bandera==0)
            {
                (<HTMLDivElement>document.getElementById('alerta')).innerHTML='<div class="alert alert-warning" role="alert">No se encontro la cuenta</div>';
            }
            

        }
    }
}